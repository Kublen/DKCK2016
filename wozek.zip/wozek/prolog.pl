zdanie(move(A, B, C, D, E, F)) --> cz(A), cecha(B,C), gdzie(D,E,F).
zdanie(move(A, B, C, D, E, F)) --> cz(A), gdzie(D,E,F), cecha(B,C).

cz(mv) --> [przenies].
cz(mv) --> [przestaw].
cz(mv) --> [wez].
cz(mv) --> [przewiez].

cecha(red, container) --> [czerwony,kontener].
cecha(yellow, container) --> [zolty,kontener].
cecha(green, container) --> [zielony,kontener].
cecha(red, container) --> [kontener,czerwony].
cecha(yellow, container) --> [kontener,zolty].
cecha(green, container) --> [kontener,zielony].

gdzie(on, shelf, nr1) --> [na, polke, pierwsza].
gdzie(on, shelf, nr1) --> [na, polke, 1].
gdzie(on, shelf, nr1) --> [na, pierwsza, polke].
gdzie(on, shelf, nr2) --> [na, polke, druga].
gdzie(on, shelf, nr2) --> [na, polke, 2].
gdzie(on, shelf, nr2) --> [na, druga, polke].
gdzie(on, shelf, nr3) --> [na, polke, trzecia].
gdzie(on, shelf, nr3) --> [na, polke, 1].
gdzie(on, shelf, nr3) --> [na, trzecia, polke].
gdzie(on, shelf, nr4) --> [na, polke, czwarta].
gdzie(on, shelf, nr4) --> [na, polke, 1].
gdzie(on, shelf, nr4) --> [na, czwarta, polke].
gdzie(on, shelf, nr5) --> [na, polke, piata].
gdzie(on, shelf, nr5) --> [na, polke, 1].
gdzie(on, shelf, nr5) --> [na, piata, polke].
gdzie(on, shelf, nrout) --> [do, strefy, out].
gdzie(on, shelf, nrout) --> [na, strefe,out].


