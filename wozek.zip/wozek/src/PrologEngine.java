import org.jpl7.*;
import java.util.Map;

public class PrologEngine 
{
           
    public static String get_solution(String word){
        
    	word = word.replaceAll(" ", ",");
    	Map<String, Term> solution = null;
    	
    	String t1 = "consult('prolog.pl')";
    	Query.hasSolution(t1);
    	
    	Query q1 = new Query("zdanie(X,[" + word +"],[])");
        
    	while ( q1.hasMoreSolutions() ){
            solution = q1.nextSolution();
        }
    	return solution.get("X").toString();
        
        
    }
   
    

}