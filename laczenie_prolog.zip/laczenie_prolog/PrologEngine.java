import org.jpl7.*;
import java.util.Map;

public class PrologEngine 
{
           
    public static String get_solution(String word){
        
    	word = word.replaceAll(" ", ",");
    	Map<String, Term> solution = null;
    	
    	Query q1 = new Query("zdanie(X,[" + word+"],[]).");
        
    	while ( q1.hasMoreSolutions() ){
            solution = q1.nextSolution();
        }
    	return solution.get("X").toString();
        
        
    }
   
    

}