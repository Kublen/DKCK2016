import java.awt.Dimension;

import javax.swing.JPanel;

public class Polecenia extends JPanel{
	
	
	public void Polecania(){
		
		setPreferredSize(new Dimension(300,500));
		
	}
	
	

}
